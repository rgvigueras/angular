import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { CurrenciesComponent } from "./currencies/currencies.component";
import { PortfoliosComponent } from "./portfolios/portfolios.component";
import { MatCardModule } from "@angular/material/card";
import {
  MatTableModule,
  MatIconModule,
  MatButtonModule,
  MatDialogModule,
  MatFormFieldModule,
  MatSnackBarModule,
  MatInputModule,
  MatListModule,
  MatSelectModule,
} from "@angular/material";
import { RouterModule } from "@angular/router";
import { MainComponent } from "./main/main.component";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AuthInterceptorService } from "./auth-interceptor.service";
import { ReactiveFormsModule } from "@angular/forms";
import { CurrencyModalComponent } from "./currencies/currencymodal/currencymodal.component";
import { PortfoliosService } from "./portfolios/portfolios.service";
import { CurrenciesService } from "./currencies/currencies.service";
import { PortFolioModalComponent } from "./portfolios/portfoliomodal/portfoliomodal.component";
import { PortfolioLineModalComponent } from "./portfolios/portfolio-line-modal/portfolio-line-modal.component";

@NgModule({
  declarations: [
    AppComponent,
    CurrenciesComponent,
    PortfoliosComponent,
    MainComponent,
    CurrencyModalComponent,
    PortFolioModalComponent,
    PortfolioLineModalComponent,
  ],
  entryComponents: [
    CurrencyModalComponent,
    PortFolioModalComponent,
    PortfolioLineModalComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatCardModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    RouterModule,
    MatDialogModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
  ],
  providers: [
    PortfoliosService,
    CurrenciesService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
