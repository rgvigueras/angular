import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CurrenciesComponent } from "./currencies/currencies.component";
import { MainComponent } from "./main/main.component";
import { PortfoliosComponent } from "./portfolios/portfolios.component";

const routes: Routes = [
  { path: "currencies", component: CurrenciesComponent },
  { path: "portfolios", component: PortfoliosComponent },
  { path: "main", component: MainComponent },
  { path: "", component: MainComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
