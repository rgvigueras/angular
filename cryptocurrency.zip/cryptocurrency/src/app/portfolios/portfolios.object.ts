export interface PortFolio {
  id: number;
  name: string;
  expanded: boolean;
  lines: PortFolioLine[];
}

export interface PortFolioLine {
  id: number;
  portfolioId: number;
  coinId: number;
  amount: number;
}
