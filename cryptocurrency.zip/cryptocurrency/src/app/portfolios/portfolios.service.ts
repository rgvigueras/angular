import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { PortFolio, PortFolioLine } from "./portfolios.object";

@Injectable({
  providedIn: "root",
})
export class PortfoliosService {
  constructor(private _httpClient: HttpClient) {}

  fetchPortFolios(): Observable<PortFolio[]> {
    return this._httpClient.get<PortFolio[]>(
      `${environment.apiBase}/portfolios`
    );
  }

  addPortFolio(portFolio: PortFolio): Promise<any> {
    return this._httpClient
      .post(`${environment.apiBase}/portfolios`, portFolio, {
        observe: "response",
      })
      .toPromise();
  }

  updatePortFolio(portFolio: PortFolio): Promise<any> {
    return this._httpClient
      .put(`${environment.apiBase}/portfolios/${portFolio.id}`, portFolio, {
        observe: "response",
      })
      .toPromise();
  }

  deletePortFolio(portfolioId: number): Promise<any> {
    return this._httpClient
      .delete(`${environment.apiBase}/portfolios/${portfolioId}`, {
        observe: "response",
      })
      .toPromise();
  }

  fetchPortFolioLines(portfolioId: number): Observable<any> {
    return this._httpClient.get(
      `${environment.apiBase}/portfolios/${portfolioId}/lines`
    );
  }

  addPortFolioLine(portFolioLine: PortFolioLine): Promise<any> {
    return this._httpClient
      .post(
        `${environment.apiBase}/portfolios/${portFolioLine.portfolioId}/lines`,
        portFolioLine,
        {
          observe: "response",
        }
      )
      .toPromise();
  }

  updatePortFolioLine(portFolioLine: PortFolioLine): Promise<any> {
    return this._httpClient
      .put(
        `${environment.apiBase}/portfolios/${portFolioLine.portfolioId}/lines/${portFolioLine.id}`,
        portFolioLine,
        {
          observe: "response",
        }
      )
      .toPromise();
  }

  deletePortFolioLine(
    portfolioId: number,
    portfolioLineId: number
  ): Promise<any> {
    return this._httpClient
      .delete(
        `${environment.apiBase}/portfolios/${portfolioId}/lines/${portfolioLineId}`,
        {
          observe: "response",
        }
      )
      .toPromise();
  }
}
