import { Component, Inject, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { PortFolio } from "../portfolios.object";

@Component({
  selector: "app-portfoliomodal",
  templateUrl: "./portfoliomodal.component.html",
  styleUrls: ["./portfoliomodal.component.scss", "../../shared.scss"],
})
export class PortFolioModalComponent implements OnInit {
  portFolioForm: FormGroup;
  portFolio: PortFolio;

  constructor(
    private _formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<PortFolioModalComponent>
  ) {
    if (data) {
      this.portFolio = data;
    }
  }

  ngOnInit() {
    this.portFolioForm = this._formBuilder.group({
      id: this.portFolio ? this.portFolio.id : null,
      name: [this.portFolio ? this.portFolio.name : "", [Validators.required]],
    });
  }
}
