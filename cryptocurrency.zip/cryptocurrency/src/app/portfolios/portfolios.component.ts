import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material";
import { SnackBarService } from "../snack-bar.service";
import { PortfolioLineModalComponent } from "./portfolio-line-modal/portfolio-line-modal.component";
import { PortFolioModalComponent } from "./portfoliomodal/portfoliomodal.component";
import { PortFolio, PortFolioLine } from "./portfolios.object";
import { PortfoliosService } from "./portfolios.service";

@Component({
  selector: "app-portfolios",
  templateUrl: "./portfolios.component.html",
  styleUrls: ["./portfolios.component.scss"],
})
export class PortfoliosComponent implements OnInit {
  displayedColumns = ["menu", "id", "name"];
  portFolios = [];

  constructor(
    private _portFoliosService: PortfoliosService,
    private _dialog: MatDialog,
    private _snackBarService: SnackBarService
  ) {}

  ngOnInit() {
    this._portFoliosService.fetchPortFolios().subscribe((res) => {
      this.portFolios = res;
    });
  }

  newPortFolio() {
    const dialogRef = this._dialog.open(PortFolioModalComponent, {
      width: "400px",
      height: "200px",
    });

    dialogRef.afterClosed().subscribe((portfolio) => {
      if (portfolio) {
        this._portFoliosService
          .addPortFolio(portfolio)
          .then((response) => {
            if (response.ok) {
              this.portFolios = [...this.portFolios, response.body];
              this._snackBarService.openSnackBar("PortFolio added");
            }
          })
          .catch((error) => console.log(error));
      }
    });
  }

  updatePortFolio(oldPortFolio: PortFolio) {
    const dialogRef = this._dialog.open(PortFolioModalComponent, {
      width: "400px",
      height: "250px",
      data: oldPortFolio,
    });

    dialogRef.afterClosed().subscribe((portfolio) => {
      if (portfolio) {
        this._portFoliosService
          .updatePortFolio(portfolio)
          .then((response) => {
            if (response.ok) {
              const portFolioIndex = this.portFolios.findIndex(
                (x) => x.id === response.body.id
              );
              this.portFolios[portFolioIndex] = response.body;
              this.portFolios = [...this.portFolios];
              this._snackBarService.openSnackBar("Portfolio updated");
            }
          })
          .catch((error) => console.log(error));
      }
    });
  }

  deletePortFolio(portfolio: PortFolio) {
    this._portFoliosService
      .deletePortFolio(portfolio.id)
      .then((response) => {
        if (response.ok) {
          this.portFolios = this.portFolios.filter(
            (x) => x.id !== portfolio.id
          );
          this._snackBarService.openSnackBar("Portfolio deleted");
        }
      })
      .catch((error) => console.log(error));
  }

  clickPortFolio(portFolio: PortFolio): void {
    portFolio.expanded = !portFolio.expanded;
    if (portFolio.expanded) {
      this._portFoliosService
        .fetchPortFolioLines(portFolio.id)
        .subscribe((res) => {
          portFolio.lines = res;
        });
    }
  }

  newPortFolioLine() {
    const dialogRef = this._dialog.open(PortfolioLineModalComponent, {
      width: "400px",
      height: "400px",
    });

    dialogRef.afterClosed().subscribe((portFolioLine) => {
      if (portFolioLine) {
        this._portFoliosService
          .addPortFolioLine(portFolioLine)
          .then((response) => {
            if (response.ok) {
              const line = response.body;
              const lines = this.portFolios.find(
                (x) => x.id === portFolioLine.portfolioId
              ).lines;
              lines.push(line);
              this._snackBarService.openSnackBar("PortFolioLine added");
            }
          })
          .catch((error) => console.log(error));
      }
    });
  }

  updatePortFolioLine(oldPortFolioLine: PortFolioLine) {
    const dialogRef = this._dialog.open(PortfolioLineModalComponent, {
      width: "400px",
      height: "400px",
      data: oldPortFolioLine,
    });

    dialogRef.afterClosed().subscribe((portFolioLine) => {
      this._portFoliosService
        .updatePortFolioLine(portFolioLine)
        .then((response) => {
          if (response.ok) {
            const portFolioIndex = this.portFolios.findIndex(
              (x) => x.id === response.body.id
            );
            const portFolioLineIndex = this.portFolios[portFolioIndex].lines(
              (x) => x.id === response.body.id
            );
            this.portFolios[portFolioIndex].lines[portFolioLineIndex] =
              response.body;
            this.portFolios = [...this.portFolios];
            this._snackBarService.openSnackBar(
              `PortFolioLine ${oldPortFolioLine.id} updated`
            );
          }
        })
        .catch((error) => console.log(error));
    });
  }

  deletePortFolioLine(portFolioLine: PortFolioLine) {
    this._portFoliosService
      .deletePortFolioLine(portFolioLine.portfolioId, portFolioLine.id)
      .then((response) => {
        if (response.ok) {
          this.portFolios = this.portFolios
            .find((x) => x.id === portFolioLine.portfolioId)
            .lines.filter((x) => x.id !== portFolioLine.id);
          this._snackBarService.openSnackBar(
            `PortFolioLine ${portFolioLine.id} deleted`
          );
        }
      })
      .catch((error) => console.log(error));
  }
}
