import { Component, Inject, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Observable } from "rxjs";
import { Currency } from "src/app/currencies/currencies.object";
import { CurrenciesService } from "src/app/currencies/currencies.service";
import { PortFolio, PortFolioLine } from "../portfolios.object";
import { PortfoliosService } from "../portfolios.service";

@Component({
  selector: "app-portfolio-line-modal",
  templateUrl: "./portfolio-line-modal.component.html",
  styleUrls: ["./portfolio-line-modal.component.scss", "../../shared.scss"],
})
export class PortfolioLineModalComponent implements OnInit {
  portFolioLineForm: FormGroup;
  portFolioLine: PortFolioLine;
  currencies$: Observable<Currency[]>;
  portFolios$: Observable<PortFolio[]>;

  constructor(
    private _formBuilder: FormBuilder,
    private _currenciesService: CurrenciesService,
    private _portFoliosService: PortfoliosService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<PortfolioLineModalComponent>
  ) {
    if (data) {
      this.portFolioLine = data;
    }
  }

  ngOnInit() {
    this.portFolioLineForm = this._formBuilder.group({
      id:
        this.portFolioLine && this.portFolioLine.id
          ? this.portFolioLine.id
          : null,
      coinId: [
        this.portFolioLine && this.portFolioLine.coinId
          ? this.portFolioLine.coinId
          : null,
        [Validators.required],
      ],
      portfolioId: [
        this.portFolioLine && this.portFolioLine.portfolioId
          ? this.portFolioLine.portfolioId
          : null,
        [Validators.required],
      ],
      amount: [
        this.portFolioLine ? this.portFolioLine.amount : "",
        [Validators.required],
      ],
    });

    this.currencies$ = this._currenciesService.fetchCoins();
    this.portFolios$ = this._portFoliosService.fetchPortFolios();
  }
}
