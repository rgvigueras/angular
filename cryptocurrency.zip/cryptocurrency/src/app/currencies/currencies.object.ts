export interface Currency {
  id: number;
  acronym: string;
  name: string;
}

export const ALL_COINS = "AllCoins";
