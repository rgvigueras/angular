import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { environment } from "src/environments/environment";
import { Currency } from "./currencies.object";

@Injectable({
  providedIn: "root",
})
export class CurrenciesService {
  constructor(private _httpClient: HttpClient) {}

  fetchCoins(): Observable<Currency[]> {
    return this._httpClient.get<Currency[]>(`${environment.apiBase}/coins`);
  }

  fetchAllCoins(): Observable<any> {
    return this._httpClient.get(
      `https://min-api.cryptocompare.com/data/all/coinlist`
    );
  }

  addCurrency(currency: Currency): Promise<any> {
    return this._httpClient
      .post(`${environment.apiBase}/coins`, currency, {
        observe: "response",
      })
      .toPromise();
  }

  updateCurrency(currency: Currency): Promise<any> {
    return this._httpClient
      .put(`${environment.apiBase}/coins/${currency.id}`, currency, {
        observe: "response",
      })
      .toPromise();
  }

  deleteCurrency(currencyId: number): Promise<any> {
    return this._httpClient
      .delete(`${environment.apiBase}/coins/${currencyId}`, {
        observe: "response",
      })
      .toPromise();
  }
}
