import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { SnackBarService } from "../snack-bar.service";
import { ALL_COINS, Currency } from "./currencies.object";
import { CurrenciesService } from "./currencies.service";
import { CurrencyModalComponent } from "./currencymodal/currencymodal.component";

@Component({
  selector: "app-currencies",
  templateUrl: "./currencies.component.html",
  styleUrls: ["./currencies.component.scss"],
})
export class CurrenciesComponent implements OnInit {
  displayedColumns = ["menu", "id", "acronym", "name"];
  currencies: Currency[];

  constructor(
    private _currencyService: CurrenciesService,
    private _dialog: MatDialog,
    private _snackBarService: SnackBarService
  ) {}

  ngOnInit() {
    this._currencyService.fetchCoins().subscribe((res) => {
      this.currencies = res;
    });

    let allCoins: string[] = JSON.parse(sessionStorage.getItem(ALL_COINS));
    if (!allCoins) {
      this._currencyService.fetchAllCoins().subscribe((res) => {
        const entries = Object.entries(res.Data);
        entries.forEach((entry) => {
          allCoins = [...allCoins, entry[0]];
        });
        sessionStorage.setItem(ALL_COINS, JSON.stringify(allCoins));
      });
    }
  }

  newCurrency() {
    const dialogRef = this._dialog.open(CurrencyModalComponent, {
      width: "400px",
      height: "300px",
    });

    dialogRef.afterClosed().subscribe((currency) => {
      if (currency && this.validCurrency(currency.acronym)) {
        this._currencyService
          .addCurrency(currency)
          .then((response) => {
            if (response.ok) {
              this.currencies = [...this.currencies, response.body];
              this._snackBarService.openSnackBar("Currency added");
            }
          })
          .catch((error) => console.log(error));
      } else {
        this._snackBarService.openSnackBar("You should enter a valid Coin");
      }
    });
  }

  updateCurrency(oldCurrency: Currency) {
    const dialogRef = this._dialog.open(CurrencyModalComponent, {
      width: "400px",
      height: "300px",
      data: oldCurrency,
    });

    dialogRef.afterClosed().subscribe((currency) => {
      if (currency) {
        this._currencyService
          .updateCurrency(currency)
          .then((response) => {
            if (response.ok) {
              const currencyIndex = this.currencies.findIndex(
                (x) => x.id === response.body.id
              );
              this.currencies[currencyIndex] = response.body;
              this.currencies = [...this.currencies];
              this._snackBarService.openSnackBar("Currency updated");
            }
          })
          .catch((error) => console.log(error));
      }
    });
  }

  deleteCurrency(currency: Currency) {
    this._currencyService
      .deleteCurrency(currency.id)
      .then((response) => {
        if (response.ok) {
          this.currencies = this.currencies.filter((x) => x.id !== currency.id);
          this._snackBarService.openSnackBar("Currency deleted");
        }
      })
      .catch((error) => console.log(error));
  }

  private validCurrency(acronym: string): boolean {
    const allCoins: string[] = JSON.parse(sessionStorage.getItem(ALL_COINS));
    return allCoins.some((x) => x === acronym);
  }
}
