import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root",
})
export class AppService {
  clientId = "webfg-test";
  clientPassword = "WW58YJj89ltR43Cr";
  username = "test001";
  password = "ryby3NTyKduAMcvZ";

  constructor(private _httpClient: HttpClient) {}

  getAccessToken(): Observable<any> {
    const headers = new HttpHeaders().set(
      "Authorization",
      "Basic " + btoa(`${this.clientId}:${this.clientPassword}`)
    );
    return this._httpClient.post(
      `${environment.apiBase}/oauth/token?grant_type=password&username=${this.username}&password=${this.password}&scope=uaa.user`,
      {},
      {
        headers: headers,
        observe: "response",
      }
    );
  }

  fetchData(): Observable<any> {
    const tokenData = JSON.parse(sessionStorage.getItem("tokenData"));

    const headers = new HttpHeaders()
      .set("Accept", "application/vnd.solid-v1.0+json")
      .set("Accept-Encoding", "gzip, deflate");

    return this._httpClient.get(
      `${environment.apiBase}/quotes/2970161-1058-814?fields= LVAL_NORM,CLOSE_ADJ_NORM,NC2_PR_NORM,NC2_NORM,VOL,TUR,PY_CLOSE,YTD_PR_NORM`,
      {
        headers: headers,
        observe: "response",
      }
    );
  }
}
