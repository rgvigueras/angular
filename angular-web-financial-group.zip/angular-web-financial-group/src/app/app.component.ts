import { Component, OnDestroy, OnInit } from "@angular/core";
import { Subject } from "rxjs";
import { ItemValue } from "./app.objects";
import { AppService } from "./app.service";
import { takeUntil } from "rxjs/operators";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit, OnDestroy {
  dataTable: ItemValue[];
  displayedColumns = ["Name", "Value", "Date"];
  unSubscribe: Subject<any>;

  constructor(private _appService: AppService) {
    this.unSubscribe = new Subject();
    this.dataTable = [];
  }

  ngOnInit(): void {
    this._appService
      .fetchData()
      .pipe(takeUntil(this.unSubscribe))
      .subscribe((res: any) => {
        const field = res.body.quotes[0].fields;
        const apiNames = Object.keys(field);
        apiNames.forEach((name) => {
          this.dataTable = [...this.dataTable, this.convertData(field, name)];
        });
      });
  }

  ngOnDestroy(): void {
    this.unSubscribe.next();
    this.unSubscribe.complete();
  }

  convertData(field: any, name: string) {
    const conversionName = {
      LVAL_NORM: "Last",
      CLOSE_ADJ_NORM: "Close",
      NC2_PR_NORM: "Day Change %",
      NC2_NORM: "Day Change",
      VOL: "Volume",
      TUR: "Turnover",
      PY_CLOSE: "Previous year close",
      YTD_PR_NORM: "YTD %",
    };

    return {
      name: conversionName[name] || "",
      value:
        name === "YTD_PR_NORM" || name === "NC2_PR_NORM"
          ? `${field[name].v} %`
          : field[name].v,
      date: field[name].d,
    };
  }
}
