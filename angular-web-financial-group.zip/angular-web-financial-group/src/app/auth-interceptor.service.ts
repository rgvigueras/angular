import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders,
} from "@angular/common/http";
import { from, Observable } from "rxjs";
import { AppService } from "./app.service";

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {
  constructor(private _appService: AppService) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (!request.url.includes("token")) {
      return from(
        this._appService
          .getAccessToken()
          .toPromise()
          .then((tokenData) => {
            const headers = new HttpHeaders().set(
              "Authorization",
              `Bearer ${tokenData.body.access_token}`
            );
            const authReq = request.clone({ headers });
            return next.handle(authReq).toPromise();
          })
      );
    } else {
      return next.handle(request);
    }
  }
}
