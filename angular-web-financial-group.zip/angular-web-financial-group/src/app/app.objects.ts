export interface ItemValue {
  name: string;
  value: string;
  date: Date;
}
